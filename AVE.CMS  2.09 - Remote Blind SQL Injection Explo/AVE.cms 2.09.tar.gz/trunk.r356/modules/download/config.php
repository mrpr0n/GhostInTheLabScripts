<?php
$wmz_purse     = "Zxxxx";
$wmz_secretkey = "xxxxxxxxxx_произвольный набор символов идентичный заданному в мерчанте xxxxxxxxx";
$wmr_purse     = "Rxxxx";
$wmr_secretkey = "xxxxxxxxxx_произвольный набор символов идентичный заданному в мерчанте xxxxxxxxx";

$host   = "localhost";
$db     = "name_db";
$login  = "user_db";
$pass   = "you password";
$perfix = "cp";
?>