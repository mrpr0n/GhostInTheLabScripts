//                  
// 	ClearBox Language File (JavaScript)
//

var

	CB_NavTextPrv='elхzх',					// text of previous image
	CB_NavTextNxt='kцvetkezх',				// text of next image
	CB_NavTextFull='teljes mйretы kйp megtekintйse',	// text of original size (only at pictures)
	CB_NavTextOpen='megnyitбs a bцngйszхben',		// text of open content in a new browser window
	CB_NavTextDL='letцltйs',				// text of download picture or any other content
	CB_NavTextClose='clearbox ablak bezбrбsa',		// text of close CB
	CB_NavTextStart='slideshow elindнtбsa',			// text of start slideshow
	CB_NavTextStop='slideshow megбllнtбsa',			// text of stop slideshow
	CB_NavTextRotR='kйp elforgatбsa jobbra 90 fokkal',	// text of rotation right
	CB_NavTextRotL='kйp elforgatбsa balra 90 fokkal'	// text of rotation left

;