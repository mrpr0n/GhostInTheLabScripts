//                  
// 	ClearBox Language File (JavaScript)
//

var

	CB_NavTextPrv='Цnceki',									// text of previous image
	CB_NavTextNxt='Sonraki',								// text of next image
	CB_NavTextFull='Gerзek Boyut',							// text of original size (only at pictures)
	CB_NavTextOpen='Эзeriрi Yeni Pencerede Aз',				// text of open in a new browser window
	CB_NavTextDL='Эзeriрi Yeni Pencerede Aз / Kaydet',		// text of download picture or any other content
	CB_NavTextClose='ClearBoxu Kapat',						// text of close CB
	CB_NavTextStart='Slideshow Baюlat',						// text of start slideshow
	CB_NavTextStop='Slideshow Durdur',						// text of stop slideshow
	CB_NavTextRotR='Resmi 90 Derece Saрa Зevir',			// text of rotation right
	CB_NavTextRotL='Resmi 90 Derece Sola Зevir'				// text of rotation left

;