//                  
// 	ClearBox Language File (JavaScript)
//

var

	CB_NavTextPrv='назад',											// text of previous image
	CB_NavTextNxt='вперёд',											// text of next image
	CB_NavTextFull='размер изображения',							// text of original size (only at pictures)
	CB_NavTextOpen='открыть в новом окне браузера',					// text of open in a new browser window
	CB_NavTextDL='скачать',											// text of download picture or any other content
	CB_NavTextClose='закрыть clearbox',								// text of close CB
	CB_NavTextStart='запустить слайдшоу',							// text of start slideshow
	CB_NavTextStop='остановить слайдшоу',							// text of stop slideshow
	CB_NavTextRotR='повернуть изображение на 90 градусов в право',	// text of rotation right
	CB_NavTextRotL='повернуть изображение на 90 градусов в лево'	// text of rotation left

;