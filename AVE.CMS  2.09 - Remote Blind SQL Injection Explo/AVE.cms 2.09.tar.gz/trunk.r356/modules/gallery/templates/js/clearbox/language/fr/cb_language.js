//                  
// 	ClearBox French Language File (JavaScript)
//

var

	CB_NavTextPrv='prйcйdent',				                    // texte pour image prйcйdente
	CB_NavTextNxt='suivant',					                // texte pour image suivante
	CB_NavTextFull='plein йcran',				                // texte pour l'image originale (uniquement pour les images)
	CB_NavTextOpen='ouvrir dans une nouvelle fenкtre',		    // texte pour ouvrir dans une nouvelle fenкtre
	CB_NavTextDL='tйlйcharger',				                    // texte pour tйlйcharger une image ou un autre contenu
	CB_NavTextClose='fermer',			                        // texte pour fermer clearbox
	CB_NavTextStart='dйmarrer le diaporama',			        // texte pour dйmarrer le diaporama
	CB_NavTextStop='arrкter le diaporama',			            // texte pour arrкter le diaporama
	CB_NavTextRotR='rotation de l\'image а 90° vers la droite',	// texte pour faire une rotation vers la droite
	CB_NavTextRotL='rotation de l\'image а 90° vers la gauche'	// texte pour faire une rotation vers la gauche

;