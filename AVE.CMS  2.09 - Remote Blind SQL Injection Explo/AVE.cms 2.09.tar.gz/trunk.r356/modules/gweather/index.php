<?php 
/*::::::::::::::::::::::::::::::::::::::::
 Modul: gWeather
 System name: AVE 2.08
 Short Desc:  Google Weather
 Version: 1.0  
 Authors: N.Popova, npop@abv.bg
 Last update: 05.07.2010
::::::::::::::::::::::::::::::::::::::::*/

header('Location:/index.php?');
exit;

?>