<?php
header('Location:/');
exit;
?>